/*
 * PhoneGapCommand.cpp
 *
 *  Created on: Mar 7, 2011
 *      Author: Anis Kadri
 */

#include "PhoneGapCommand.h"

PhoneGapCommand::PhoneGapCommand() : pWeb(null) {
}
PhoneGapCommand::PhoneGapCommand(Web* pWeb) : pWeb(pWeb) {
}

PhoneGapCommand::~PhoneGapCommand() {
}
