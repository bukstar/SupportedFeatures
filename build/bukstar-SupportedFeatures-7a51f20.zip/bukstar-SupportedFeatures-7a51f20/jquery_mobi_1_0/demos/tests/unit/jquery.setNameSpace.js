//set namespace for unit test markp
$( document ).bind( "mobileinit", function(){
	$.mobile.ns = "nstest-";		
});